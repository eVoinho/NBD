package entity;

import javax.persistence.Entity;

@Entity
public class test {
}
