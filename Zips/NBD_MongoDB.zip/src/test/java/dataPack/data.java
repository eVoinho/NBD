package dataPack;

import model.Book;
import model.Client;
import static model.Client.Type.*;
import model.Rent;
import org.bson.types.ObjectId;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;

public class data {

    public static Client client = new Client("Jan", "Lesniak", NORMAL);
    public static Client client2 = new Client("Jakub", "Nowak", STUDENT);
    public static Client client3 = new Client("Jon", "Kowal", PROFESSIONAL);
    public static Book book1 = new Book( "O tym jak zdac studia", "Komedia",
            401, "Maksimus Mega", 5);
    public static Book book2 = new Book( "O systemach operacyjnych slow kilka", "Dramat",
            666, "Linux Winda", 5);
    public static Book book3 = new Book( "Piesn asemblera i dosu", "Poezja",
            102, "Ryszard Kadowski", 5);


    public static Rent rent1 = new Rent(LocalDate.now(), LocalDate.now(), 0.0, client.getPersonalId(), Arrays.asList(book1.getId(), book2.getId()) );
    public static Rent rent2 = new Rent(LocalDate.now(), LocalDate.now(), 0.0, client2.getPersonalId(), Arrays.asList(book2.getId(), book3.getId()) );
    public static Rent rent3 = new Rent(LocalDate.now(), LocalDate.now(), 0.0, client3.getPersonalId(), Arrays.asList(book3.getId(), book2.getId(), book1.getId()) );

}

