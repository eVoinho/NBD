//package manager;
//
//import model.Client;
//import repository.ClientRepository;
//
//import java.util.List;
//
//public class ClientMenager {
//    ClientRepository clientRepository = new ClientRepository();
//
//    public void getClient(Client client){
//        clientRepository.addClient(client);
//    }
//
//    public void registerClient(Client client){
//        clientRepository.addClient(client);
//    }
//
//    public List<Client> findAll(){
//        return clientRepository.getClients();
//    }
//
//    public void unregisterClient(Client client){
//        clientRepository.removeClient(client);
//    }
//
//    //public void changeClientType(Client client){}
//}
