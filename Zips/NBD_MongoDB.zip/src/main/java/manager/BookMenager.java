//package manager;
//
//import model.Book;
//import repository.BookRepository;
//
//public class BookMenager {
//
//    BookRepository bookRepository = new BookRepository();
//
//    public void registerBook(Book book){
//        bookRepository.addBook(book);
//    }
//
//    public void unregisterBook(Book book){
//        bookRepository.removeBook(book);
//    }
//
//    //public void getBook(Book book){}
//}
