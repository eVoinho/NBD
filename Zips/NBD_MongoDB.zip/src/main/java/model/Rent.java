package model;


import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import org.bson.codecs.pojo.annotations.BsonCreator;
import org.bson.codecs.pojo.annotations.BsonId;
import org.bson.codecs.pojo.annotations.BsonProperty;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.bson.types.ObjectId;

@Getter
@Setter
public class Rent {

    @BsonId
    private ObjectId id;
    @BsonProperty("begin")
    private LocalDate begin;
    @BsonProperty("end")
    private LocalDate end;
    @BsonProperty("totalPenalty")
    private Double totalPenalty;
    @BsonProperty("client")
    private ObjectId client;
    @BsonProperty("books")
    private List<ObjectId> book;

    @BsonCreator
    public Rent(@BsonProperty("begin") LocalDate begin,
                @BsonProperty("end") LocalDate end,
                @BsonProperty("totalPenalty") Double totalPenalty,
                @BsonProperty("client") ObjectId client,
                @BsonProperty("books") List<ObjectId> book) {
        this.id = new ObjectId();
        this.begin = begin;
        this.end = end;
        this.totalPenalty = totalPenalty;
        this.client = client;
        this.book = book;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        Rent rent = (Rent) o;

        return new EqualsBuilder().append(id, rent.id).append(begin, rent.begin).append(end, rent.end).append(totalPenalty, rent.totalPenalty).append(client, rent.client).append(book, rent.book).isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37).append(id).append(begin).append(end).append(totalPenalty).append(client).append(book).toHashCode();
    }

    @Override
    public String toString() {
        return "Rent{" +
                "id=" + id +
                ", begin=" + begin +
                ", end=" + end +
                ", totalPenalty=" + totalPenalty +
                ", client=" + client +
                ", book=" + book +
                '}';
    }
}
