package repository;

import javax.persistence.Persistence;

import com.mongodb.MongoCommandException;
import com.mongodb.client.ClientSession;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.CreateCollectionOptions;
import com.mongodb.client.model.Updates;
import com.mongodb.client.model.ValidationOptions;
import com.mongodb.client.result.UpdateResult;
import model.Book;
import model.Client;
import model.Rent;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static com.mongodb.client.model.Filters.eq;

public class RentRepository extends Repository{


    private final MongoCollection<Rent> rentMongoCollection;
    private final MongoCollection<Book> bookMongoCollection;

    public RentRepository() {
        initConnection();
        try {
            getLibraryDB().createCollection("rents", new CreateCollectionOptions().validationOptions( new ValidationOptions().validator(
                    Document.parse(
                            """
    {
       $jsonSchema: {
          bsonType: "object",
          properties: {
             begin: {
                bsonType: "date",
                description: "must be a date"
             },
             end: {
                bsonType: "date",
                description: "must be a date"
             },
             totalPenalty: {
                bsonType: "double",
                minimum: 0,
                description: "must be a positive integer"
             }
             client: {
                bsonType: "$oid",
                minimum: 0,
                description: "must be a positive float"
             }
             book: {
                bsonType: "array"
                description: "must be an array"
             }
          }
       }
    }
                    """
                    )
            )));
        } catch(MongoCommandException ignored) {
        }

        rentMongoCollection = getLibraryDB().getCollection("rents", Rent.class);
        bookMongoCollection = getLibraryDB().getCollection("books", Book.class);
    }
    public boolean addRent(Rent rent) {
        try (ClientSession session = getMongoClient().startSession()) {
            session.startTransaction();
            transactionBody(rent);
            session.commitTransaction();
        } catch (RuntimeException e) {
            return false;
        }
        return true;
    }

    private void transactionBody(Rent rent) {
        System.out.println(rent.toString());
        for(ObjectId oid: rent.getBook()){
            Bson filter = eq("_id", oid);

            ArrayList<Book> ls = bookMongoCollection.find(filter, Book.class).into(new ArrayList<> ());
            System.out.println(bookMongoCollection.find(filter).into(new ArrayList<>()));
            if(ls.isEmpty() || ls.get(0) == null || isExisting(rent) || ls.get(0).getQuantity() == 0) {
                throw new RuntimeException();
                }
            }


        updateDataBase(rent, rent.getBook());
    }


    private void updateDataBase(Rent rent, List<ObjectId> book) {
        for(ObjectId oid: book) {
            Bson fil = eq("_id", book);
            Bson update = Updates.inc("quantity", -1);
            bookMongoCollection.findOneAndUpdate(fil, update);
        }

        rentMongoCollection.insertOne(rent);
    }

    private boolean isExisting(Rent rent) {
        ArrayList<Rent> ls = find(rent.getId());
        return !ls.isEmpty();
    }

    public Rent removeRent(ObjectId id) {

        Rent rent;
        Bson rentFilter = eq("_id", id);
        ClientSession session = getMongoClient().startSession();

        session.startTransaction();
        rent = rentMongoCollection.findOneAndDelete(rentFilter);
        Bson update = Updates.inc("quantity", 1);
        assert rent != null;
        Bson showFilter = eq("_id", rent.getBook());
        bookMongoCollection.updateOne(showFilter, update);
        session.commitTransaction();

        return rent;
    }

    public void drop()
    {
        rentMongoCollection.drop();
    }

    public ArrayList<Rent> findAll() {
        return rentMongoCollection.find().into(new ArrayList<> ());
    }

    public ArrayList<Rent> find(ObjectId id) {
        Bson filter = eq("id", id);

        return rentMongoCollection.find(filter).into(new ArrayList<> ());
    }

    public Rent updateOne(ObjectId id, Bson updateOperation) {
        Bson filter = eq("id", id);
        return rentMongoCollection.findOneAndUpdate(filter, updateOperation);
    }

    public UpdateResult updateMany(Bson filter, Bson updateOperation) {
        return rentMongoCollection.updateMany(filter, updateOperation);
    }

}